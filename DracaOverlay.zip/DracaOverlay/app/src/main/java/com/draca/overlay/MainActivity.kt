// kotlin, android, app module, target: MainActivity (overlay permission + launch)
package com.draca.overlay

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.status_text)
        val startBtn = findViewById<Button>(R.id.start_btn)

        startBtn.setOnClickListener {
            if (hasOverlayPermission()) {
                startOverlay()
            } else {
                requestOverlayPermission()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (hasOverlayPermission()) {
            statusText.text = "permissão ok. toque de novo pra abrir o overlay."
        } else {
            statusText.text = "toque para ativar o overlay"
        }
    }

    private fun hasOverlayPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun startOverlay() {
        startService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }
}
